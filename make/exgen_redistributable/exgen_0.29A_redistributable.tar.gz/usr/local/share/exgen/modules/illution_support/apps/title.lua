include("lib/latex.lua");

tex = latex_interface:new();
tex.image_size = 'bbox';
tex.output_format = 'gif';
tex.source = [[
\\documentclass[letterpaper]{report}
\\usepackage[T1]{fontenc}
\\usepackage{yfonts}
\\usepackage{color}
\\usepackage[usenames,dvipsnames,svgnamesm,table]{xcolor}
\\begin{document}
    \\thispagestyle{empty}
    \\pagecolor{black}
    \\usefont{T1}{pag}{m}{n}
    \\textcolor{red}{
    \\Huge illution
    }
    \\normalsize
\\end{document}
]]

tex.create_document();
tex.download_page();
tex.destroy_document();
echo( tex.page_count.."\n");

window1 = window.new();
window1.visible = 1;


box = surface:new();
box.parent = window1;
box.top = window1.margin_top;
box.left = window1.margin_left;
box.height = window1.height - window1.margin_top - window1.margin_bottom;
box.width = window1.width - window1.margin_left - window1.margin_right;
box.backcolor = makecol(0, 0, 0);
box.clear();

box.visible = 1;

logo = surface:new();
logo.gif = tex.pages[1] --"6079c6b9abb1fa0aa1e33d2434bbe213_1.jpg"
logo.parent = window1;
logo.top = window1.margin_top;
logo.left = window1.margin_left;
logo.z = 9999;
logo.visible = 1;
