
while 1 == 1 do
    keyval, keycode = readkey();
    echo(keyval.." "..keycode.."\n");
end