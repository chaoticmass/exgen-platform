sad_words = {
    "doubt",
    "fear",
    "pain",
    "hate",
    "ignore",
    "lost",
    "worthless"
}