include("lib/form.lua");
font1 = surface:new();
font1.visible = 0;
font1.bmp = 'fonts/small.bmp';



load_form("department");
