


worldspace_class = {};
function worldspace_class:new()
    local object = {};
    local daters = {};
    daters.ws = create_worldspace();

    setmetatable(object, {
	-- GET DATA
	__index = function (table, key) 
	    if key == "face_count" then
		--return get_model_face_count(daters.model);
	    end
	    return daters[key];
	end,
	-- SET DATA
	__newindex = function (table, key, value)
	    daters[key] = value;
	end	
    }
    );

    daters.create_plane = function ()
	return create_plane(daters.ws);
    end
    
    daters.simulate = function ()
	simulate(daters.ws);
    end

    daters.simulate_step = function (step)
	simulate(daters.ws, step);
    end
        
    return object;
end

body_class = {};
function body_class:new(worldspace)
    local object = {};
    local daters = {};
    daters.body = create_body(worldspace.ws); 
    setmetatable(object, {
	-- GET DATA
	__index = function (table, key) 
	    if key == "x" then
		--return get_camera_x(daters.camera);
	    else 
		return daters[key];
	    end
	end,
	-- SET DATA
	__newindex = function (table, key, value)
	    if key == "x" then
		--set_camera_x(daters.camera, value);
	    else
		daters[key] = value;
	    end
	    daters[key] = value;
	end	
    }
    );

	
    daters.get_position = function () 
	return body_get_position(daters.body);
    end

    daters.set_position = function (x, y, z) 
	body_set_position(daters.body, x, y, z);
    end


    return object;
end
