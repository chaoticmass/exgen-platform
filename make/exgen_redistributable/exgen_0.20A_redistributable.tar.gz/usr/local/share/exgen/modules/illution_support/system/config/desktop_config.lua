setvar("desktop", "forecolor", makecol(128, 128, 255));
setvar("desktop", "backcolor", makecol(32, 32, 128));
setvar("windows", "got-focus-alpha", 0);
setvar("windows", "lost-focus-alpha", 128);
setvar("windows", "fade-in-speed", 256);
setvar("windows", "fade-out-speed", 512);
setvar("windows", "fade-windows", 0);