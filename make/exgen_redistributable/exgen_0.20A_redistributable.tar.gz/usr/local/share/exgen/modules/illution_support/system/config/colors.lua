setvar("colors", "widget-forecolor", makecol(190, 190, 190));
setvar("colors", "widget-backcolor", makecol(128, 128, 128));
setvar("colors", "text-color", makecol(0, 0, 0));
setvar("colors", "window-title-text-color", makecol(255, 255, 255));
setvar("colors", "window-title-forecolor", makecol(190, 190, 250));
setvar("colors", "window-title-backcolor", makecol(128, 128, 250));