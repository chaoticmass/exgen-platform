
mod_load("illution");

lua_init_script = [[
include("lib/application.lua");
include("lib/gui.lua");
include("lib/term.lua");
include("lib/db.lua");
]];
setvar("configuration", "lua-init-script", lua_init_script);
reinit();

set_debug_mode(1);

initialize_video(640, 480);

include("system/config/system_config.lua");
include("system/config/colors.lua");
include("system/config/desktop_config.lua");
mouse = surface:new();
mouse.top = 0;
mouse.left = 0;
mouse.width = 16;
mouse.height = 16;
mouse.transparent = 1;
mouse.backcolor = makecol(255, 0, 255);
mouse.forecolor = makecol(0, 0, 0);
mouse.clear();
mouse.always_on_top = 1;
--mouse.print(0,0,"X");
mouse.bmp = "system/images/cursor.bmp";
mouse.z = 9999;


mouse.on_draw = function()
    x, y = mouse_xy();
    --echo("mouse on draw\n");
    mouse.top = y;
    mouse.left = x;
--    mouse.z = 9999;    
end

branch("system/taskbar.lua");
branch("system/desktop.lua");
branch("apps/dead_simple.lua");
--branch("apps/simple.lua");


--[[

Render loop without arguments runs the render loop on the root surface.
This thread owns the root surface.

]]
render_loop();
