
--include("system/config/desktop_config.lua");


desktop = surface:new();
desktop.top = 0;
desktop.left = 0;
desktop.width = screen_width();
desktop.height = screen_height();
desktop.z = -1;
desktop.forecolor = getvar("desktop", "forecolor");
desktop.backcolor = getvar("desktop", "backcolor");
--desktop.gif = "images/eds_wall.gif";
--desktop.alpha = 255;
desktop.on_draw = function ()
    if (desktop.bmp ~= nil) then
	echo("bitmap\n");
    else
	desktop.gradient(desktop.forecolor, desktop.backcolor);
    end
--[[    if (desktop.alpha > 0) then
	desktop.alpha = desktop.alpha - 1;
    end]]
end

desktop.on_click = function ()
--    run = input_dialog:new();
--    run.show();
--    echo(run.input.text);
end

--[[
font1 = surface:new();
font1.visible = 0;
font1.bmp = "fonts/small.bmp";


icon = surface:new();
icon.visible = 0;
icon.fuck = 1;
icon.gif = "images/icons/folder.gif";



ibox = iconbox:new();
ibox.parent = desktop;
ibox.width = screen_width();
ibox.height = screen_height();
ibox.top = 6;
ibox.left = 6;
ibox.font = font1;
ibox.backcolor = makecol(255, 0, 255);
ibox.transparent = 1;
ibox.z = 1;
ibox.arrange_vertical = 0;

ibox.add_icon("Woop", icon, "", "");
for i = 0, 10 do
    ibox.add_icon("Icon "..i, icon, "", "");
end

ibox.on_icon_activate = function (icon) 
    echo(icon.caption.." actuvated\n");
    ibox.z = 1;
end
]]

render_loop(desktop.surface);