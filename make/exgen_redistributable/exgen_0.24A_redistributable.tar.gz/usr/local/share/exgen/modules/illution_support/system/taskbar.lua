font1 = surface:new();
font1.visible = 0;
font1.bmp = "fonts/black_micro_computer.bmp";

task = surface:new();
task.height = 32;
task.width = screen_width();
task.left = 0;
task.top = screen_height() - task.height;
task.forecolor = getvar("colors", "widget-forecolor");
task.backcolor = getvar("colors", "widget-backcolor");
--task.alpha = 100;

task.on_draw = function()
    task.gradient(task.forecolor, task.backcolor);
end

button1 = button:new();
button1.parent = task;
button1.top = 3;
button1.left = 3;
button1.height = 26;
button1.caption = "illution";

button1.on_click = function ()
    --branch("apps/physics.lua");
    branch("apps/memory_meter.lua");
end
render_loop(task.surface);