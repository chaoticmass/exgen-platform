


model_class = {};
function model_class:new(model_filename)
    local object = {};
    local daters = {};
    daters.model = create_model();
    if (type(model_filename) == 'string') then
	daters.filename = model_filename;
	load_3ds(daters.model, model_filename);
    end

    setmetatable(object, {
	-- GET DATA
	__index = function (table, key) 
	    if key == "face_count" then
		return get_model_face_count(daters.model);
	    end
	    return daters[key];
	end,
	-- SET DATA
	__newindex = function (table, key, value)
	    daters[key] = value;
	end	
    }
    );

    daters.add_face = function ()
	model_add_face(daters.model);
    end
    
    daters.set_face_data = function (face, vertex, x, y, z, u, v, c)
	set_model_face_data(daters.model, face, vertex, x, y, z, u, v, c);
    end

    daters.set_offset = function (ox, oy, oz)
	set_model_offset(daters.model, ox, oy, oz);
    end
    
    daters.get_face_data = function (face, vertex)
	return get_model_face_data(daters.model, face, vertex);
    end
    
    return object;
end

camera_class = {};
function camera_class:new()
    local object = {};
    local daters = {};
    daters.camera = create_camera(); 
    daters.surface = surface:new();
    set_camera_bitmap(daters.camera, get_surface_bitmap(daters.surface.surface));
    setmetatable(object, {
	-- GET DATA
	__index = function (table, key) 
	    if key == "x" then
		return get_camera_x(daters.camera);
	    elseif key == "y" then
		return get_camera_y(daters.camera);
	    elseif key == "z" then
		return get_camera_z(daters.camera);
	    elseif key == "pitch" then
		return get_camera_pitch(daters.camera);
	    elseif key == "heading" then
		return get_camera_heading(daters.camera);
	    else 
		return daters[key];
	    end
	end,
	-- SET DATA
	__newindex = function (table, key, value)
	    if key == "x" then
		set_camera_x(daters.camera, value);
	    elseif key == "y" then
		set_camera_y(daters.camera, value);
	    elseif key == "z" then
		set_camera_z(daters.camera, value);
	    elseif key == "pitch" then
		set_camera_pitch(daters.camera, value);
	    elseif key == "heading" then
		set_camera_heading(daters.camera, value);
	    else
		daters[key] = value;
	    end
	    daters[key] = value;
	end	
    }
    );

    daters.look_at = function (entity)
	dx = daters.x - entity.x;
--	if dx < 0 then
--	    dx = entity.x - daters.x;
--	end
	dy = entity.y - daters.y;
--	if dy < 0 then
--	    dy = daters.y - entity.y;
--	end
	
	object.heading = math.deg(math.atan(dy / dx));

	dx = entity.x - daters.x ;
--	if (dx < 0) then
--	    dx = entity.x - daters.x;
--	end
	dy = entity.z - daters.z;
--	if (dy < 0) then
--	    dy = daters.z - entity.z;
--	end
	
	object.pitch = math.deg(math.atan(dy / dx));
    end

    daters.turn_to = function (entity)
	dx = daters.x - entity.x;
--	if dx < 0 then
--	    dx = entity.x - daters.x;
--	end
	dy = entity.y - daters.y;
--	if dy < 0 then
--	    dy = daters.y - entity.y;
--	end
	--echo(object.heading.."\n");
	object.heading = math.deg(math.atan(dy / dx));

    end
	
    daters.update = function () 
	set_camera_bitmap(daters.camera, get_surface_bitmap(daters.surface.surface));
	daters.surface.clear();
	update_camera(daters.camera);
    end

    daters.initialize = function () 
	set_camera_bitmap(daters.camera, get_surface_bitmap(daters.surface.surface));
	daters.surface.clear();
	initialize_camera(daters.camera);
	update_camera(daters.camera);
    end


    return object;
end

entity_class = {};
function entity_class:new()
    local object = {};
    local daters = {};

    daters.matrix = create_matrix();
    daters.collision_model = model_class:new();
    
    setmetatable(object, {
	-- GET DATA
	__index = function (table, key) 
	    if key == "x" then
		return get_matrix_x(daters.matrix);
	    elseif key == "y" then
		return get_matrix_y(daters.matrix);
	    elseif key == "z" then
		return get_matrix_z(daters.matrix);
	    elseif key == "r_x" then
		return get_matrix_r_x(daters.matrix);
	    elseif key == "r_y" then
		return get_matrix_r_y(daters.matrix);
	    elseif key == "r_z" then
		return get_matrix_r_z(daters.matrix);
	    elseif key == "scale" then
		return get_matrix_pitch(daters.matrix);
	    else 
		return daters[key];
	    end
	end,
	-- SET DATA
	__newindex = function (table, key, value)
	    if key == "scale" then
		set_matrix_scale(daters.matrix, value);
	    elseif key == "x" then
		set_matrix_x(daters.matrix, value);
	    elseif key == "y" then
		set_matrix_y(daters.matrix, value);
	    elseif key == "z" then
		set_matrix_z(daters.matrix, value);
	    elseif key == "r_x" then
		set_matrix_r_x(daters.matrix, value);
	    elseif key == "r_y" then
		set_matrix_r_y(daters.matrix, value);
	    elseif key == "r_z" then
		set_matrix_r_z(daters.matrix, value);
	    else
		daters[key] = value;
	    end
	    daters[key] = value;
	end	
    }
    );

    daters.update = function () 
	update_matrix(daters.matrix, daters.model.model, daters.collision_model.model);
    end
    
    daters.set_rotation = function (w, x, y, z)
	set_matrix_rotation(daters.matrix, w, x, y, z);
    end
    
    daters.render = function (camera)
	render_model(daters.model.model, daters.matrix, camera.camera, get_surface_bitmap(daters.texture.surface), get_surface_bitmap(camera.surface.surface));
	camera.surface.set_dirty();
    end

    daters.render_wireframe = function (camera)
	render_model_wireframe(daters.model.model, daters.matrix, camera.camera, get_surface_bitmap(camera.surface.surface));
	camera.surface.set_dirty();
    end

    daters.render_gouraud = function (camera)
	render_model_gouraud(daters.model.model, daters.matrix, camera.camera, get_surface_bitmap(camera.surface.surface));
	camera.surface.set_dirty();
    end

    return object;
end

surface3d_class = {};
function surface3d_class:new()
    local object = {};
    local square = {};

    square = entity_class:new();
    square.model = model_class:new();
    square.model.add_face();
    square.model.add_face();
			    --        x,	y, 	z, 	u, 	v, 	c
    square.model.set_face_data(0, 0, 0, 	0, 	0, 	0, 	0, 	0);			
    square.model.set_face_data(0, 1, 64, 	0, 	0, 	128, 	0, 	0);
    square.model.set_face_data(0, 2, 64, 	0, 	64, 	128, 	128, 	0);

    
    square.model.set_face_data(1, 0, 64, 	0, 	64,	128, 	128, 	0);
    square.model.set_face_data(1, 1, 0, 	0, 	64,	0, 	128, 	0);
    square.model.set_face_data(1, 2, 0, 	0, 	0, 	0, 	0, 	0);

    setmetatable(object, {
	-- GET DATA
	__index = function (table, key) 
	    if key == "x" then
		return square.x;
	    elseif key == "y" then
		return square.y;
	    else 
		return square[key];
	    end
	end,
	-- SET DATA
	__newindex = function (table, key, value)
	    if key == "x" then
		square.x = value;
	    elseif key == "y" then
		square.y = value;
	    elseif key == "texture" then
		square.texture = value;
		hw = value.width * .5;
		hh = value.height * .5;
		square.model.set_face_data(0, 0, 0 - hw, 	0, 	0 - hh, 	0, 		0, 	0);			
		square.model.set_face_data(0, 1, hw, 		0, 	0 - hh, 	value.width, 	0, 	0);
		square.model.set_face_data(0, 2, hw, 		0, 	hh, 		value.width, 	value.height, 	0);
    
		square.model.set_face_data(1, 0, hw, 		0, 	hh,	value.width, 	value.height, 	0);
		square.model.set_face_data(1, 1, 0 - hw, 	0, 	hh,	0, 	value.height, 	0);
		square.model.set_face_data(1, 2, 0 - hw, 	0, 	0 - hh, 	0, 	0, 	0);
	    else
		square[key] = value;		
	    end
	    square[key] = value;
	end	
    }
    );
    return object;
end

--model, texture_width, texture_height, side_length, origin_x, origin_y
create_cube = function(cube, cube_width, cube_height, side_length, origin_x, origin_y, origin_z, color) 
--cube = model_class:new();

l = side_length * 0.5;
ox = origin_x;
oy = origin_y;
oz = origin_z;

fc = cube.face_count;
cube.add_face();
cube.add_face();

cube.set_face_data(fc+0, 0, 	ox-l,  oy-l,  oz-l,   0,   0, color);
cube.set_face_data(fc+0, 1, 	ox+l, oy-l,  oz-l, cube_width,   0, color);
cube.set_face_data(fc+0, 2, 	ox+l, oy-l, oz+l, cube_width, cube_height, color);

cube.set_face_data(fc+1, 0, 	ox+l, oy-l, oz+l, cube_width, cube_height, color);
cube.set_face_data(fc+1, 1, 	ox-l, oy-l, oz+l,   0, cube_height, color);
cube.set_face_data(fc+1, 2, 	ox-l, oy-l,  oz-l,   0,   0, color);

cube.add_face();
cube.add_face();

cube.set_face_data(fc+2, 0, 	ox-l, oy-l,  oz-l,   0,   cube_height, color);
cube.set_face_data(fc+2, 1, 	ox-l, oy+l,  oz-l, 0,   0, color);
cube.set_face_data(fc+2, 2, 	ox-l, oy+l, oz+l, cube_width, 0, color);

cube.set_face_data(fc+3, 0, 	ox-l, oy+l, oz+l, cube_width, 0, color);
cube.set_face_data(fc+3, 1, 	ox-l, oy-l, oz+l,   cube_width, cube_height, color);
cube.set_face_data(fc+3, 2, 	ox-l, oy-l, oz-l,   0,  cube_height, color);

cube.add_face();
cube.add_face();

cube.set_face_data(fc+4, 0, 	ox+l,  oy-l,  oz-l,   cube_width,   cube_height, color);
cube.set_face_data(fc+4, 1, 	ox+l, oy+l,  oz-l, cube_width,   0, color);
cube.set_face_data(fc+4, 2, 	ox+l, oy+l, oz+l, 0, 0, color);
 
cube.set_face_data(fc+5, 0, 	ox+l, oy+l, oz+l, 0, 0, color);
cube.set_face_data(fc+5, 1, 	ox+l,  oy-l, oz+l, 0, cube_height, color);
cube.set_face_data(fc+5, 2, 	ox+l,  oy-l,  oz-l,   cube_width,   cube_height, color);

cube.add_face();
cube.add_face();

cube.set_face_data(fc+6, 0, 	ox-l,  oy+l,  oz-l,   0,   0, color);
cube.set_face_data(fc+6, 1, 	ox+l, oy+l,  oz-l, cube_width,   0, color);
cube.set_face_data(fc+6, 2, 	ox+l, oy+l, oz+l, cube_width, cube_height, color);

cube.set_face_data(fc+7, 0, 	ox+l, oy+l, oz+l, cube_width, cube_height, color);
cube.set_face_data(fc+7, 1, 	ox-l,  oy+l, oz+l,   0, cube_height, color);
cube.set_face_data(fc+7, 2,  	ox-l,  oy+l,  oz-l,   0,   0, color);

cube.add_face();
cube.add_face();

cube.set_face_data(fc+8, 0, 	ox-l,  oy-l,  oz-l,   cube_width,   cube_height, color);
cube.set_face_data(fc+8, 1, 	ox+l, oy-l,  oz-l, 0, cube_height, color);
cube.set_face_data(fc+8, 2, 	ox+l, oy+l, oz-l, 0, 0, color);

cube.set_face_data(fc+9, 0, 	ox+l, oy+l, oz-l, 0, 0, color);
cube.set_face_data(fc+9, 1, 	ox-l,  oy+l, oz-l,   cube_width, 0, color);
cube.set_face_data(fc+9, 2, 	ox-l,  oy-l,  oz-l,   cube_width,  cube_height, color);

cube.add_face();
cube.add_face();

cube.set_face_data(fc+10, 0, 	ox-l,  oy-l,  oz+l,   0,   cube_height, color);
cube.set_face_data(fc+10, 1, 	ox+l, oy-l,  oz+l, cube_width,   cube_height, color);
cube.set_face_data(fc+10, 2, 	ox+l, oy+l, oz+l, cube_width, 0, color);

cube.set_face_data(fc+11, 0, 	ox+l, oy+l, oz+l, cube_width, 0, color);
cube.set_face_data(fc+11, 1, 	ox-l,  oy+l, oz+l,   0, 0, color);
cube.set_face_data(fc+11, 2, 	ox-l,  oy-l,  oz+l,   0, cube_height, color);

end

create_3d_rectangle = function(cube, cube_width, cube_height, cube_depth, origin_x, origin_y, origin_z, color) 
--cube = model_class:new();


ox = origin_x;
oy = origin_y;
oz = origin_z;

fc = cube.face_count;
cube.add_face();
cube.add_face();

w = cube_width * 0.5;
h = cube_height * 0.5;
d = cube_depth * 0.5;
-- A
cube.set_face_data(fc+0, 0, 	ox-w,  oy-h,  oz-d,   0,   0, color);
-- B
cube.set_face_data(fc+0, 1, 	ox+w, oy-h,  oz-d, cube_width,   0, color);
-- C
cube.set_face_data(fc+0, 2, 	ox+w, oy+h, oz-d, cube_width, cube_height, color);

-- C
cube.set_face_data(fc+1, 0, 	ox+w, oy+h, oz-d, cube_width, cube_height, color);
-- D
cube.set_face_data(fc+1, 1, 	ox-w, oy+h, oz-d,   0, cube_height, color);
-- A
cube.set_face_data(fc+1, 2, 	ox-w, oy-h,  oz-d,   0,   0, color);


cube.add_face();
cube.add_face();
cube.set_face_data(fc+2, 0, 	ox-w, oy-h,  oz+d,   0,   cube_height, color);
cube.set_face_data(fc+2, 1, 	ox+w, oy-h,  oz+d, 0,   0, color);
cube.set_face_data(fc+2, 2, 	ox+w, oy+h, oz+d, cube_width, 0, color);

cube.set_face_data(fc+3, 0, 	ox+w, oy+h, oz+d, cube_width, 0, color);
cube.set_face_data(fc+3, 1, 	ox-w, oy+h, oz+d,   cube_width, cube_height, color);
cube.set_face_data(fc+3, 2, 	ox-w, oy-h, oz+d,   0,  cube_height, color);


cube.add_face();
cube.add_face();
-- A2
cube.set_face_data(fc+4, 0, 	ox-w,  oy-h,  oz+d,   cube_width,   cube_height, color);
-- A
cube.set_face_data(fc+4, 1, 	ox-w, oy-h,  oz-d, cube_width,   0, color);
-- D
cube.set_face_data(fc+4, 2, 	ox-w, oy+h, oz-d, 0, 0, color);

-- D
cube.set_face_data(fc+5, 0, 	ox-w, oy+h, oz-d, 0, 0, color);
-- D2
cube.set_face_data(fc+5, 1, 	ox-w,  oy+h, oz+d, 0, cube_height, color);
-- A2
cube.set_face_data(fc+5, 2, 	ox-w,  oy-h,  oz+d, cube_width, cube_height, color);


cube.add_face();
cube.add_face();
-- B
cube.set_face_data(fc+6, 0, 	ox+w,  oy-h,  oz-d,   0,   0, color);
-- B2
cube.set_face_data(fc+6, 1, 	ox+w, oy-h,  oz+d, cube_width,   0, color);
-- C2
cube.set_face_data(fc+6, 2, 	ox+w, oy+h, oz+d, cube_width, cube_height, color);

-- C2
cube.set_face_data(fc+7, 0, 	ox+w, oy+h, oz+d, cube_width, cube_height, color);
-- C
cube.set_face_data(fc+7, 1, 	ox+w,  oy+h, oz-d,   0, cube_height, color);
-- B
cube.set_face_data(fc+7, 2,  	ox+w,  oy-h,  oz-d,   0,   0, color);


cube.add_face();
cube.add_face();
-- A2
cube.set_face_data(fc+8, 0, 	ox-w,  oy-h,  oz+d,   cube_width,   cube_height, color);
-- B2
cube.set_face_data(fc+8, 1, 	ox+w, oy-h,  oz+d, 0, cube_height, color);
-- B
cube.set_face_data(fc+8, 2, 	ox+w, oy-h, oz-d, 0, 0, color);

-- B
cube.set_face_data(fc+9, 0, 	ox+w, oy-h, oz-d, 0, 0, color);
-- A
cube.set_face_data(fc+9, 1, 	ox-w,  oy-h, oz-d,   cube_width, 0, color);
-- A2
cube.set_face_data(fc+9, 2, 	ox-w,  oy-h,  oz+d,   cube_width,  cube_height, color);


cube.add_face();
cube.add_face();
-- D
cube.set_face_data(fc+10, 0, 	ox-w,  oy+h,  oz-d,   0,   cube_height, color);
-- C
cube.set_face_data(fc+10, 1, 	ox+w, oy+h,  oz-d, cube_width,   cube_height, color);
-- C2
cube.set_face_data(fc+10, 2, 	ox+w, oy+h, oz+d, cube_width, 0, color);

-- C2
cube.set_face_data(fc+11, 0, 	ox+w, oy+h, oz+d, cube_width, 0, color);
-- D2
cube.set_face_data(fc+11, 1, 	ox-w,  oy+h, oz+d,   0, 0, color);
-- D
cube.set_face_data(fc+11, 2, 	ox-w,  oy+h,  oz-d,   0, cube_height, color);
end


create_model_from_image =  function(model, surface, scale, size) 
    w = surface.width - 1;
    h = surface.height - 1;

--    size = 64;
    thing = size;
    hw = (w * .5) * thing;
    hh = (h * .5) * thing;
    
    for y=1, h, scale do
	for x=1, w, scale do
	    c = surface.get_pixel(x, y);
	    r, g, b = get_rgb(c);
	    echo(x..", "..y.." = "..r.."\n");
	    if r > 128 then
			--  model, 0, 0, size, ox,     oy,    oz, color
		create_cube(model, 0, 0, size, hw - (x*thing), hh-(y*thing), 0, makecol(255, 255, 255));
		echo("Create Cube: "..x..", "..y.."\n");
	    else
	    end
	end
    end
end