terminal = {};
function terminal:new()
    local object = {};
    local daters = {};

    daters.surface = surface:new();
    daters.surface.rows = 25;
    daters.surface.cols = 80;

    vt = vt_create(daters.surface.rows, daters.surface.cols);

    daters.surface.vt = vt;

    vt_update(vt);
    term = daters.surface;
    term.vt = vt;
    term.pid = 0;
    setmetatable(object, {
	-- GET DATA
	__index = function (table, key) 
	    return daters.surface[key];
	end,
	-- SET DATA
	__newindex = function (table, key, value)
	    daters.surface[key] = value;
	end	
    }
    );
    daters.surface.termcolor = function (color)
	if (color == 0) then
	    retval = makecol(0, 0, 0);
	elseif (color == 1) then -- red
    	    retval = makecol(255, 0, 0);
	elseif (color == 2) then -- green
	    retval = makecol(0, 255, 0);
	elseif (color == 3) then -- yellow
    	    retval = makecol(0, 255, 255);
	elseif (color == 4) then -- blue
    	    retval = makecol(0, 0, 255);
	elseif (color == 5) then -- magenta
    	    retval = makecol(128, 0, 0);
	elseif (color == 6) then -- cyan
    	    retval = makecol(0, 0, 128);
	elseif (color == 7) then -- white
    	    retval = makecol(255, 255, 255);
	end
	return retval;
    end

    daters.surface.drawterm = function ()
        daters.surface.clear();
	
	set_thread_priority(100);
    
	xpos = 0;
	ypos = 0;
	
	vt = daters.surface.vt;
	term = daters.surface;
	rows = term.rows;
	cols = term.cols;
	termcolor = term.termcolor;
        ccol = vt_cursor_col(vt);
	crow = vt_cursor_row(vt);
	ysize = term.text_height();
	xsize = 8;
	term.orig_bg = term.backcolor;
	term.orig_fg = term.forecolor;
	
	this_line = "";    
        white = makecol(255, 255, 255);
	for row = 0, rows - 1, 1 do
	    for col = 0, cols - 1, 1 do
		char = vt_char(vt, row, col);
		xsize = term.text_length(char);
		this_line = this_line .. char;
		if (crow == row) then
		    if (ccol == col) then
			term.print(xpos, ypos, "_");
		    end
		end
		xpos = xpos + xsize;
	    end
	    xpos = 0;
	    term.print(xpos, ypos, this_line);
	    this_line = "";
	    
	    ypos = ypos + ysize;
	end
    
	vt_clean(vt);
	term.backcolor = term.orig_bg;
	term.forecolor = term.orig_fg;
	
	set_thread_priority(getvar("configuration", "default-thread-priority"));
    end 


    daters.surface.old_drawterm = function ()
        daters.surface.clear();
	
	set_thread_priority(100);
    
	xpos = 0;
	ypos = 0;
	
	vt = daters.surface.vt;
	term = daters.surface;
	rows = term.rows;
	cols = term.cols;
	termcolor = term.termcolor;
        ccol = vt_cursor_col(vt);
	crow = vt_cursor_row(vt);
	ysize = term.text_height();
	xsize = 8;
	term.orig_bg = term.backcolor;
	term.orig_fg = term.forecolor;
	    
        white = makecol(255, 255, 255);
	for row = 0, rows - 1, 1 do
	    for col = 0, cols - 1, 1 do
		char = vt_char(vt, row, col);
		xsize = term.text_length(char);
		fg = 0; --termcolor(vt_fgcolor(vt, row, col));
		bg = 0; --termcolor(vt_bgcolor(vt, row, col));

		if (crow == row) then
		    if (ccol == col) then
			fg, bg = bg, fg;
			term.print(xpos, ypos, "_");
		    end
		end
		term.backcolor = bg;
		term.forecolor = fg;
		term.print(xpos, ypos, char);
		xpos = xpos + xsize;
	    end
	    xpos = 0;
	    ypos = ypos + ysize;
	end
    
	vt_clean(vt);
	term.backcolor = term.orig_bg;
	term.forecolor = term.orig_fg;
	
	set_thread_priority(getvar("configuration", "default-thread-priority"));
    end 

    daters.surface.keyhandler = function ()
	--[[key, scan = readkeyscan();
        if (key == 0) then
	    vt_keypress(vt, vt_convscan(scan));
	else
	    vt_keypress(vt, key);
	end
	if (key == 57) then
	    quit();
	end ]]
	
    end


    term.on_draw = function ()
	vt_update(term.vt);
        if (vt_dirty(term.vt)) then
    	    term.drawterm();
	    echo("draw\n");
	    if (type(term.on_vt_dirty) == 'function') then
		term.on_vt_dirty();
	    end
	end    
	term.set_dirty();
    end

    term.on_keypress = function (keycode, keyval)
	if (type(term.before_keypress) == 'function') then
	    keycode, keyval = term.before_keypress(keycode, keyval);
	else 
	    if (keyval == 0) then
		vt_keypress(vt, vt_convscan(keycode));
	    else
		vt_keypress(vt, keyval);
	    end    
	end
        term.on_draw();
	term.set_dirty();
	if (type(term.after_keypress) == 'function') then
	    term.after_keypress(keycode, keyval);
	end
    end    

    term.write = function (string)
	vt_write(term.vt, string);
	term.set_dirty();
    end

    term.forkpty = function (cmd) 
	term.pid = vt_forkpty(term.vt, cmd);
	--vt_forsake_child(term.vt);
	term.on_draw();
	term.set_dirty();
    end

    return object;
end


